from persistencia import guardar_pedido

guardar_pedido("camilo", " asstros")
    